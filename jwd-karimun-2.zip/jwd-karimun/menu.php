
        <img src="images/gambar.jpeg" width="900px">
        <hr>

        <div class="menu">
            <a href="index.php" > Home </a> || 
            <a href="daftar_buku.php">Daftar Buku</a> ||
            <a href="tambah_buku.php">Tambah Buku</a>
        </div>
        <hr>
