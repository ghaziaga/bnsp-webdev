
    <img src="images/gambar.jpeg" width="1000px" height="80px"> 
    <br><br>
    <div class="menu">
        <a href='index.php'> Home </a> ||
        <a href='daftar_buku.php'> Daftar Buku </a> ||
        <a href='tambah_buku.php'> Tambah Buku </a> ||
        <a href='peminjaman_buku.php'> Peminjaman Buku </a>
    </div>
