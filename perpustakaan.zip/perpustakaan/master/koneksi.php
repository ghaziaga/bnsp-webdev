<?php
    $connect = mysqli_connect("localhost", "root", "", "Perpustakaan");
